module.exports = {
  project: {
    ios: {},
    android: {},
  },
  assets: ['./source/assets/fonts/']
};